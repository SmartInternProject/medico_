import java.sql.*;

class Connjdbc {

    public static void main(String args[]) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/assignment2", "root", "1234");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select Name from Students where age=10");
            while (rs.next())
                System.out.println(rs.getString("Name"));
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}